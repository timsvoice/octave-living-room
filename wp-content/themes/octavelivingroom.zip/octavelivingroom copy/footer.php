    <script src="<?php bloginfo('template_url'); ?>/js/app.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/bower_components/jquery/jquery.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/bower_components/foundation/js/foundation.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/bower_components/foundation/js/foundation/foundation.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/bower_components/foundation/js/foundation/foundation.topbar.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/bower_components/foundation/js/app.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/bower_components/foundation/js/foundation/foundation.dropdown.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/bower_components/foundation/js/foundation/foundation.orbit.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/bower_components/foundation/js/foundation/foundation.accordion.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/bower_components/foundation/js/foundation/foundation.reveal.js"></script>

    <script> $(document).foundation(); </script>
  </body>
</html>